# terraform-module-cdn

Terraform modules that provisions CloudFront + Route53 + ACM + S3 to serve static assets, SPAs, etc

### Usage

```hcl
module "app" {
  source = "../../modules/cf-cdn"

  providers = {
    aws.eu-central-1 = aws
    aws.us-east-1    = aws.us-east-1
  }

  app_name        = "Name of the APP"
  aws_region      = "eu-central-1"
  domain_name     = local.domain_name
  route53_zone_id = data.terraform_remote_state.route53.outputs.zone_id

  env  = var.env
  tags = local.tags
}
```
