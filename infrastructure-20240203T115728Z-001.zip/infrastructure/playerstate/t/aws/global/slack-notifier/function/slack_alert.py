#!/usr/bin/python3.8
import os
import requests
import json

slack_token = os.getenv('SLACK_TOKEN')
slack_channel = os.getenv('SLACK_CHANNEL')
slack_icon_emoji = ''
slack_user_name = os.getenv('SLACK_USERNAME')

def post_message_to_slack(text, blocks = None):
  return requests.post('https://slack.com/api/chat.postMessage', {
    'token': slack_token,
    'channel': slack_channel,
    'text': text,
    'icon_emoji': slack_icon_emoji,
    'username': slack_user_name,
    'blocks': json.dumps(blocks) if blocks else None
  })

def lambda_handler(event, context):

  message = event['Records'][0]['Sns']['Message']

  ClusterName = [msg['value'] for msg in message['Trigger']['Dimensions'] if msg['name']=='ClusterName']
  ServiceName = [msg['value'] for msg in message['Trigger']['Dimensions'] if msg['name']=='ServiceName']

  blocks = [
    {
      "type": "header",
      "text": {
        "type": "plain_text",
        "text": message['AlarmName'],
        "emoji": True
      }
    },
    {
      "type": "section",
      "text": {
        "type": "plain_text",
        "text": message['AlarmDescription'],
        "emoji": True
      }
    },
    {
      "type": "divider"
    },
    {
      "type": "section",
      "text": {
        "type": "mrkdwn",
        "text": "*Cluster Name*: {}".format(ClusterName[0])
      }
    },
    {
      "type": "section",
      "text": {
        "type": "mrkdwn",
        "text": "*Service Name*: {}".format(ServiceName[0])
      }
    },
    {
      "type": "section",
      "text": {
        "type": "mrkdwn",
        "text": "*Time:* {}".format(message['StateChangeTime'])
      }
    }
  ]

  result = post_message_to_slack(
    "Text shown in popup.",
    blocks);

  print({
    "message": message,
    "status_code": result.status_code,
    "response": result.json()
  })
