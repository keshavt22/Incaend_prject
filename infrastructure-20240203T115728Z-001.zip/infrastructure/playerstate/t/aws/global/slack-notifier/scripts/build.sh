#!/bin/bash

echo "Executing build.sh..."

echo "SRC_PATH: ${SRC_PATH}"
echo "PATH_MODULE: ${PATH_MODULE}"
echo "PATH_CWD: ${PATH_CWD}"

cd $PATH_CWD
echo "Cleaning up..."
rm -rf .tmp

BUILD_DIR=.tmp/build
mkdir -p $BUILD_DIR

# Copy function code to build dir
echo "Copy function code to build dir..."
cp -r ./$SRC_PATH/* ./$BUILD_DIR

# Installing python dependencies...
FILE=$PATH_CWD/$SRC_PATH/requirements.txt

if [ -f "$FILE" ]; then
  echo "Installing dependencies..."
  echo "From: requirements.txt file exists..."
  pip3 install --target ./$BUILD_DIR -r "$FILE"

else
  echo "Error: requirements.txt does not exist!"
fi

echo "Finished script execution!"
