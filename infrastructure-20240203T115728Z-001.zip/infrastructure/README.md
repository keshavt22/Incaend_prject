# infrastructure

## Goal

We want our infrastructure for each project to be automated, using [Terraform](https://www.terraform.io) and [Ansible](https://www.ansible.com) initially but maybe moving to a different process as time goes on. 

## Reasons:

- Consistency (all servers for a project should look identical)
- Versioning (our infrastructure should be version managed so we can track changes and rollback with ease)
- Maintainability (we shouldn't need to manually log on to every server we run to get updates on them)
- Scalability (You can scale quicker when you don't have to configure anything manually)
- Reliability (AWS instances, for example, are known to 'disappear'. Rebuilding should take seconds, not hours)
- Flexibility (We can rebuild reasonably quickly on any IaaS, as long as we use the same unerlying OS)

## Plan

The components needed should be:

- Load balancer
- App instances
- Database instances (or SaaS offerings)

There should be a separation between these so we can scale app instances and database instances separately. All environments should be identical.

To facilitate this automation we have settled (initially) on [Terraform](https://www.terraform.io) and [Ansible](https://www.ansible.com).

Terraform will be used to instantiate the underlying infrastructure:

- AWS VPC (per project)
- AWS Load Balancer
- AWS VPC instances (app)
- AWS VPC instances (db)
- AWS Security Groups (with correct firewall rules)

Once these are instantiated, Ansible will begin the configuration of each.

## Future Options

- We could possibly run a PaaS like Flock, Cloud Foundry, etc. This could accomodate a lot of our application and service decisions later.
- Maybe we don't need any of our own instances at all, and we just use Heroku and the services available.
