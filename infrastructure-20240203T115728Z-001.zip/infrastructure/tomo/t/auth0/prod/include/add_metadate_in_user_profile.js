function (user, context, callback) {
  const namespace = `https://${auth0.domain}/claims/`;
  context.idToken[namespace + 'user_metadata'] = user.user_metadata;
  context.idToken[namespace + 'app_metadata'] = user.app_metadata;
  context.idToken[namespace + 'identities'] = user.identities;
  const data = {
    clientID: user.clientID,
    user_id: user.user_id,
    created_at: user.created_at,
    updatedAt: user.updated_at
  };
  context.idToken[namespace + 'data'] = data;
  return callback(null, user, context);
}
