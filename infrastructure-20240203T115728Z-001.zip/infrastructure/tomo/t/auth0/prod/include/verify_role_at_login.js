function (user, context, callback) {
  user.app_metadata = user.app_metadata || {};
  user.app_metadata.roles = user.app_metadata.roles || [];

  if(context.clientName === "OPS") {
    if (user.app_metadata.roles.indexOf('admin') > -1 ||
        user.app_metadata.roles.indexOf('doctor') > -1){
       callback(null, user, context);
    } else {
      callback("Your are not auhtorized", user, context);
    }
  } else {
    callback(null, user, context);
  }
}
