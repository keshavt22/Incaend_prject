function (user, context, callback) {
  user.user_metadata = user.user_metadata || {};
  user.user_metadata.internal_user = user.user_metadata.internal_user || 'no';

  ['incaendo.com','activate.co.uk','hellotomo.co.uk'].some(
    function (domain) {
      var emailSplit = user.email.split('@');
      if (emailSplit[emailSplit.length - 1].toLowerCase() === domain) {
        user.user_metadata.internal_user = 'yes';
      }
    }
  );

  auth0.users.updateUserMetadata(user.user_id, user.user_metadata)
    .then(function(){
      callback(null, user, context);
    })
    .catch(function(err){
      callback(err);
    });
}
