function (user, context, callback) {
  user.app_metadata = user.app_metadata || {};
  user.app_metadata.user_type = user.app_metadata.user_type || '';
  user.app_metadata.paid_user = user.app_metadata.paid_user || false;
  user.app_metadata.special_user = user.app_metadata.special_user || false;
  if (typeof  user.user_metadata !== 'undefined') {
    user.app_metadata.campaign = typeof user.user_metadata.campaignId !== 'undefined' ? user.user_metadata.campaignId : '';
    user.app_metadata.campaign_duration = typeof user.user_metadata.courseExpiryDate !== 'undefined' ? user.user_metadata.courseExpiryDate : 0;
    user.app_metadata.course =  typeof user.user_metadata.course !== 'undefined' ? user.user_metadata.course : '';
    user.app_metadata.sub_user_type = '';
  }

  if(context.clientID === "uxnCbRK1f8ouxb41QwzRbih5yXG8pOeG") {
    var timestamp = 1509474480000 ;
    var userCreatedAt = new Date(user.created_at).getTime();
    var currentTimestamp = new Date().getTime();
    var subscribedDomain = ['incaendo.com', 'activate.co.uk', 'hellotomo.co.uk', 'orcha.co.uk', 'saga.co.uk', 'cbtclinics.co.uk'];
    user.app_metadata.user_type = 'individual';
    user.app_metadata.paid_user = false;

    if (timestamp > userCreatedAt) {
      user.app_metadata.user_type = 'corporate';
      user.app_metadata.paid_user = true;
    } else if (user.app_metadata.special_user) {
      user.app_metadata.user_type = 'corporate';
      user.app_metadata.paid_user = true;
    } else if (typeof user.app_metadata.campaign !== 'undefined' && user.app_metadata.campaign !== '') {
      var courseExpiry = (typeof user.app_metadata.campaign_duration !== 'undefined') ? new Date(user.app_metadata.campaign_duration).getTime() : '';
      if (currentTimestamp < courseExpiry) {
        user.app_metadata.user_type = 'corporate';
        user.app_metadata.sub_user_type = 'course';
        user.app_metadata.course_duration = courseExpiry;
        user.app_metadata.campaign_duration = courseExpiry;
        user.app_metadata.paid_user = true;
      }
    } else {
        subscribedDomain.some(
          function (domain) {
            var emailSplit = user.email.split('@');
            var userHavingDomain = emailSplit[emailSplit.length - 1].toLowerCase();
            if (userHavingDomain === domain) {
              user.app_metadata.user_type = 'corporate';
              user.app_metadata.paid_user = true;
            }
            if (userHavingDomain === 'venturethree.com') {
              user.app_metadata.sub_user_type = 'venturethree';
            }
        });
    }
  }

  auth0.users.updateAppMetadata(user.user_id, user.app_metadata)
    .then(function() {
      return callback(null, user, context);
    })
    .catch(function(err){
      callback(err);
    });
}
