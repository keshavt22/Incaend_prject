Example usage of the module where you want the EC2 instances from the cluster to be launched within existing subnets of the VPC
