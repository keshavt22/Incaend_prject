Example usage of the module where you want the module to create the VPC for you and launch the EC2 instances within the public subnets of that newly created VPC
