#!/usr/bin/python3
from lambda_function import lambda_handler

event = {}
context = None
if __name__ == "__main__":
    lambda_handler(event, context)
