#!/usr/bin/python3
import requests


def lambda_handler(event, context):
    urls = ["http://dev.ecohedge.com/api/initCurrencies", "https://stage.ecohedge.com/api/initCurrencies",
            "https://app.ecohedge.com/api/initCurrencies"]
    print("test")
    for url in urls:
        response = requests.get(url)
        print(f"Response for {url}: {response}")
